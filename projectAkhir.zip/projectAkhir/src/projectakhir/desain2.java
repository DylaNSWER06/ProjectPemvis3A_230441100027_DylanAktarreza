/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir;

import java.io.FileOutputStream;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.io.File;
import javax.swing.ListSelectionModel;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author USER
 */
public class desain2 extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel modelProduk;
    private DefaultTableModel modelPenjualan;
    public desain2() {
        initComponents();
        conn = koneksi.getConnection();
        
        initTableModels();
        loadDataProduk();
        clearProdukFields();
    }
    
    private void initTableModels() {
        modelProduk = new DefaultTableModel(new String[] { "ID", "Nama Produk", "Keterangan", "Stok Produk", "Harga Produk" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        tbl_Produk.setModel(modelProduk);
        
        modelPenjualan = new DefaultTableModel(new String[] { "ID detail", "ID produk", "nama_produk", "barang terjual", "TOTAL" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        tbl_Penjualan.setModel(modelPenjualan);
    }
    
        
    //    menampilkan ke table
    private void loadDataProduk() {
        modelProduk.setRowCount(0);
        try {
            String sql = "SELECT * FROM produk";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                modelProduk.addRow(new Object[]{
                    rs.getInt("id_produk"),
                    rs.getString("nama_produk"),
                    rs.getString("keterangan"),
                    rs.getString("stok"),
                    rs.getString("harga")
                });
            }
            
            tbl_Produk.repaint();
        } catch (SQLException e) {
            System.out.println("Error Load Data Produk: " + e.getMessage());
        }
    }
    
    private void loadLaporanPenjualan() {
    // Hapus semua data di tabel laporan penjualan sebelumnya
    modelPenjualan.setRowCount(0);

    try {
        // Query SQL untuk memuat data dengan id_detail
        String sql = "SELECT " +
                     "dt.id_detail, " +
                     "dt.id_produk, " +
                     "p.nama_produk, " +
                     "dt.stok_terjual AS barang_terjual, " +
                     "dt.total_harga AS total " +
                     "FROM detail_transaksi dt " +
                     "JOIN produk p ON dt.id_produk = p.id_produk";
                     
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        // Tambahkan data ke dalam tabel
        while (rs.next()) {
            modelPenjualan.addRow(new Object[]{
                rs.getInt("id_detail"),
                rs.getInt("id_produk"),
                rs.getString("nama_produk"),
                rs.getInt("barang_terjual"),
                rs.getInt("total")
            });
        }

        // Refresh tabel
        tbl_Penjualan.repaint();

    } catch (SQLException e) {
        System.out.println("Error Load Data Laporan Penjualan: " + e.getMessage());
    }
}

    
    public class PDFExporter {

    public void exportSelectedRowToPDF(JTable table, String filePath) {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Silakan pilih satu baris dari tabel terlebih dahulu.", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();

        exportToPDF(tableModel, selectedRow, filePath);

        openPDF(filePath);
    }
    private void exportToPDF(DefaultTableModel tableModel, int rowIndex, String filePath) {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            document.add(new Phrase("Data Resep Terpilih\n\n"));

            // Membuat tabel PDF dengan jumlah kolom sesuai tabel
            PdfPTable table = new PdfPTable(tableModel.getColumnCount());

            // Header tabel
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                table.addCell(new PdfPCell(new Phrase(tableModel.getColumnName(i))));
            }

            // Data baris yang dipilih
            for (int col = 0; col < tableModel.getColumnCount(); col++) {
                table.addCell(new PdfPCell(new Phrase(tableModel.getValueAt(rowIndex, col).toString())));
            }

            document.add(table);
            JOptionPane.showMessageDialog(null, "PDF berhasil dibuat di: " + filePath);
        } catch (DocumentException | IOException e) {
            JOptionPane.showMessageDialog(null, "Error dalam membuat PDF: " + e.getMessage());
        } finally {
            document.close();
        }
    }

    public void openPDF(String filePath) {
        try {
            File pdfFile = new File(filePath);
            if (pdfFile.exists()) {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(pdfFile);
                } else {
                    JOptionPane.showMessageDialog(null, "Desktop tidak didukung. Tidak bisa membuka PDF.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "File PDF tidak ditemukan di: " + filePath);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat membuka PDF: " + e.getMessage());
        }
    }
}
  
    
    private void tambahProduk() {
        if (tf_Namaproduk.getText().trim().isEmpty() || 
        tf_Keterangan.getText().trim().isEmpty() || 
        tf_Stokproduk.getText().trim().isEmpty() || 
        tf_Hargaproduk.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
        return;
    }
        PreparedStatement ps = null;
        try {
        String sql = "INSERT INTO produk (nama_produk, keterangan, stok, harga) VALUES (?, ?, ?, ?)";
        ps = conn.prepareStatement(sql);
        ps.setString(1, tf_Namaproduk.getText().trim());
        ps.setString(2, tf_Keterangan.getText().trim());
        ps.setString(3, tf_Stokproduk.getText().trim().toString());
        ps.setString(4, tf_Hargaproduk.getText().trim().toString());

        int affectedRows = ps.executeUpdate(); 
        if (affectedRows > 0) {
            JOptionPane.showMessageDialog(this, "Data Produk berhasil ditambahkan.");
            loadDataProduk();
            clearProdukFields();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data produk.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Kesalahan saat menambah Data Produk: " + e.getMessage(), "Kesalahan", JOptionPane.ERROR_MESSAGE);
    } 

}
    
    private void updateProduk() {
    int id;
    try {
        id = Integer.parseInt(id_Produk.getText().trim()); 
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "ID Produk tidak valid.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        return; 
    }

    if (tf_Namaproduk.getText().trim().isEmpty() || 
        tf_Keterangan.getText().trim().isEmpty() || 
        tf_Stokproduk.getText().trim().isEmpty() || 
        tf_Hargaproduk.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Semua field harus diisi.", "Peringatan", JOptionPane.WARNING_MESSAGE);
        return; 
    }

    PreparedStatement ps = null; 
    try {
        String sql = "UPDATE produk SET nama_produk = ?, keterangan = ?, stok = ?, harga = ? WHERE id_produk = ?";
        ps = conn.prepareStatement(sql);
        ps.setString(1, tf_Namaproduk.getText().trim());
        ps.setString(2, tf_Keterangan.getText().trim());
        ps.setString(3, tf_Stokproduk.getText().trim().toString());
        ps.setString(4, tf_Hargaproduk.getText().trim().toString());
        ps.setInt(5, id);

        int affectedRows = ps.executeUpdate(); 
        if (affectedRows > 0) {
            JOptionPane.showMessageDialog(this, "Data Produk berhasil diupdate.");
            loadDataProduk();
            clearProdukFields();
        } else {
            JOptionPane.showMessageDialog(this, "Gagal memperbarui data produk. ID tidak ditemukan.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Kesalahan saat memperbarui Data Produk: " + e.getMessage(), 
                                      "Kesalahan", JOptionPane.ERROR_MESSAGE);
    } 

}

    private void hapusProduk() {
    try {
        int id = Integer.parseInt(id_Produk.getText().trim());

        // Hapus data dari tabel produk
        String sqlDeleteProduk = "DELETE FROM produk WHERE id_produk = ?";
        PreparedStatement psProduk = conn.prepareStatement(sqlDeleteProduk);
        psProduk.setInt(1, id);
        psProduk.executeUpdate();

        JOptionPane.showMessageDialog(this, "Data Produk berhasil dihapus.");
        loadDataProduk();
        clearProdukFields();
    } catch (SQLException e) {
        System.out.println("Error Hapus Data Produk: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menghapus data.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "ID tidak valid.", "Kesalahan", JOptionPane.ERROR_MESSAGE);
    }
}
    
    


    private void clearProdukFields() {
        id_Produk.setText("");
        tf_Namaproduk.setText("");
        tf_Keterangan.setText("");
        tf_Stokproduk.setText("");
        tf_Hargaproduk.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Produk = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        id_Produk = new javax.swing.JTextField();
        tf_Namaproduk = new javax.swing.JTextField();
        tf_Stokproduk = new javax.swing.JTextField();
        tf_Hargaproduk = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        btn_Tambahproduk = new javax.swing.JButton();
        btn_Eproduk = new javax.swing.JButton();
        btn_Dproduk = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tf_Keterangan = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_Penjualan = new javax.swing.JTable();
        btn_kembali = new javax.swing.JButton();
        btn_Cetak = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setPreferredSize(new java.awt.Dimension(0, 700));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setPreferredSize(new java.awt.Dimension(1288, 150));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USER\\Downloads\\PUUKI.png")); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 0, -1, 150));

        jTabbedPane1.setBackground(new java.awt.Color(255, 153, 0));
        jTabbedPane1.setForeground(new java.awt.Color(51, 51, 255));
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel6.setBackground(new java.awt.Color(0, 153, 153));

        jLabel5.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TOKO TIKI");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("LIST BARANG BESERTA HARGA");

        tbl_Produk.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_Produk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_ProdukMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_Produk);

        jPanel8.setBackground(new java.awt.Color(0, 255, 204));

        jPanel9.setLayout(new java.awt.GridLayout(1, 0));

        btn_Tambahproduk.setBackground(new java.awt.Color(249, 193, 83));
        btn_Tambahproduk.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        btn_Tambahproduk.setText("TAMBAH");
        btn_Tambahproduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TambahprodukActionPerformed(evt);
            }
        });
        jPanel9.add(btn_Tambahproduk);

        btn_Eproduk.setBackground(new java.awt.Color(249, 193, 83));
        btn_Eproduk.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        btn_Eproduk.setText("EDIT");
        btn_Eproduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_EprodukActionPerformed(evt);
            }
        });
        jPanel9.add(btn_Eproduk);

        btn_Dproduk.setBackground(new java.awt.Color(249, 193, 83));
        btn_Dproduk.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        btn_Dproduk.setText("DELETE");
        btn_Dproduk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DprodukActionPerformed(evt);
            }
        });
        jPanel9.add(btn_Dproduk);

        jLabel7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ID");

        jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("nama produk");

        jLabel9.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Stok produk");

        jLabel10.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Harga satuan");

        jLabel11.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Keterangan");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(id_Produk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                            .addComponent(tf_Namaproduk, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addComponent(tf_Hargaproduk, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_Stokproduk, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_Keterangan, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(id_Produk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_Namaproduk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_Keterangan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(tf_Stokproduk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tf_Hargaproduk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(423, 423, 423)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(312, 312, 312)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(318, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addGap(262, 262, 262)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 628, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(262, Short.MAX_VALUE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(230, 230, 230))
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addGap(361, 361, 361)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(25, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("MANAJEMEN BARANG", jPanel3);

        jPanel7.setBackground(new java.awt.Color(0, 153, 153));

        jLabel6.setFont(new java.awt.Font("Comic Sans MS", 1, 48)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TOKO TIKI");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("RIWAYAT PEMBELIAN");

        tbl_Penjualan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tbl_Penjualan);

        btn_kembali.setBackground(new java.awt.Color(249, 193, 83));
        btn_kembali.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        btn_kembali.setText("KEMBALI KE HALAMAN UTAMA");
        btn_kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembaliActionPerformed(evt);
            }
        });

        btn_Cetak.setBackground(new java.awt.Color(249, 193, 83));
        btn_Cetak.setFont(new java.awt.Font("Agency FB", 0, 24)); // NOI18N
        btn_Cetak.setText("CETAK");
        btn_Cetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CetakActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(296, Short.MAX_VALUE)
                .addComponent(btn_Cetak)
                .addGap(285, 285, 285)
                .addComponent(btn_kembali)
                .addGap(264, 264, 264))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(423, 423, 423)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(424, Short.MAX_VALUE)))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(467, 467, 467)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(467, Short.MAX_VALUE)))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(299, 299, 299)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(299, Short.MAX_VALUE)))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(440, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Cetak)
                    .addComponent(btn_kembali))
                .addGap(72, 72, 72))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(470, Short.MAX_VALUE)))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(96, 96, 96)
                    .addComponent(jLabel4)
                    .addContainerGap(430, Short.MAX_VALUE)))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(136, 136, 136)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(137, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("LAPORAN PENJUALAN", jPanel5);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 154, -1, 540));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1308, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembaliActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btn_kembaliActionPerformed

    private void btn_DprodukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DprodukActionPerformed
        // TODO add your handling code here:
        hapusProduk();
    }//GEN-LAST:event_btn_DprodukActionPerformed

    private void btn_EprodukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_EprodukActionPerformed
        // TODO add your handling code here:
        updateProduk();
    }//GEN-LAST:event_btn_EprodukActionPerformed

    private void btn_TambahprodukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TambahprodukActionPerformed
        // TODO add your handling code here:
        tambahProduk();
    }//GEN-LAST:event_btn_TambahprodukActionPerformed

    private void tbl_ProdukMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_ProdukMouseClicked
        // TODO add your handling code here:
        int row = tbl_Produk.getSelectedRow();

        if (row != -1) {
            id_Produk.setText(tbl_Produk.getValueAt(row, 0).toString());
            tf_Namaproduk.setText(tbl_Produk.getValueAt(row, 1).toString());
            tf_Keterangan.setText(tbl_Produk.getValueAt(row, 2).toString());
            tf_Stokproduk.setText(tbl_Produk.getValueAt(row, 3).toString());
            tf_Hargaproduk.setText(tbl_Produk.getValueAt(row, 4).toString());
        }
    }//GEN-LAST:event_tbl_ProdukMouseClicked

    private void btn_CetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CetakActionPerformed
         // TODO add your handling code here:
        String outputPath = "Data Resep.pdf";
        PDFExporter exporter = new PDFExporter();
        exporter.exportSelectedRowToPDF(tbl_Penjualan, outputPath);   
    }//GEN-LAST:event_btn_CetakActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(desain1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(desain1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(desain1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(desain1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new desain2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Cetak;
    private javax.swing.JButton btn_Dproduk;
    private javax.swing.JButton btn_Eproduk;
    private javax.swing.JButton btn_Tambahproduk;
    private javax.swing.JButton btn_kembali;
    private javax.swing.JTextField id_Produk;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tbl_Penjualan;
    private javax.swing.JTable tbl_Produk;
    private javax.swing.JTextField tf_Hargaproduk;
    private javax.swing.JTextField tf_Keterangan;
    private javax.swing.JTextField tf_Namaproduk;
    private javax.swing.JTextField tf_Stokproduk;
    // End of variables declaration//GEN-END:variables
}
